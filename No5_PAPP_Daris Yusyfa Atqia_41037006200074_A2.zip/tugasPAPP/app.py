from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root@localhost/db_data'  # Ganti dengan konfigurasi MySQL Anda
db = SQLAlchemy(app)

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content = db.Column(db.String(200))

@app.route('/items/', methods=['GET'])
def get_item(id):
    item = Item.query.get(id)
    del item.__dict__['_sa_instance_state']
    return jsonify(item.__dict__)

@app.route('/items', methods=['GET'])
def get_items():
    items = []
    for item in db.session.query(Item).all():
        del item.__dict__['_sa_instance_state']
        items.append(item.__dict__)
    return jsonify(items)

@app.route('/items', methods=['POST'])
def create_item():
    body = request.form
    db.session.add(Item(title=body['title'], content=body['content']))
    db.session.commit()
    return "item created"

@app.route('/items/', methods=['PUT'])
def update_item(id):
    body = request.form
    db.session.query(Item).filter_by(id=id).update(
        dict(title=body['title'], content=body['content']))
    db.session.commit()
    return "item updated"

@app.route('/items/', methods=['DELETE'])
def delete_item(id):
    db.session.query(Item).filter_by(id=id).delete()
    db.session.commit()
    return "item deleted"

if __name__ == '__main__':
    app.run()
