<!DOCTYPE html>
<html>
<head>
    <title>Form Item</title>
</head>
<body>
    <h1>Create Item</h1>
    <form action="create_item.php" method="POST">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title"><br><br>
        <label for="content">Content:</label><br>
        <textarea id="content" name="content"></textarea><br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
